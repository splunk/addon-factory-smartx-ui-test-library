# SPDX-FileCopyrightText: 2020 2020
#
# SPDX-License-Identifier: Apache-2.0

FIELD_PRODUCT = "_product"
FIELD_REST_NAMESPACE = "_rest_namespace"
FIELD_REST_PREFIX = "_rest_prefix"
FIELD_PROTOCOL_VERSION = "_protocol_version"
FIELD_VERSION = "_version"
FIELD_ENCRYPTION_FORMATTER = "_encryption_formatter"
